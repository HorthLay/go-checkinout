<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\AttendanceOffDay;
use App\Models\Mission;
use App\Models\Notification;
use App\Models\OfficeLocation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class AdminController extends Controller
{


  public function index()
    {
        // Get current month date range
        $startOfMonth = now()->startOfMonth();
        $endOfMonth = now()->endOfMonth();
        
        // Overall Statistics
        $stats = [
            'total_employees' => User::where('role_type', 'user')->count(),
            'total_present_today' => Attendance::whereDate('attendance_date', today())
                                              ->whereIn('status', ['on_time', 'late'])
                                              ->count(),
            'total_late_today' => Attendance::whereDate('attendance_date', today())
                                           ->where('status', 'late')
                                           ->count(),
            'total_absent_today' => Attendance::whereDate('attendance_date', today())
                                             ->where('status', 'absent')
                                             ->count(),
            'total_hours_month' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                            ->sum('work_hours'),
            'avg_hours_month' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                          ->avg('work_hours'),
        ];
        
        // Top 5 Performers (This Month)
        $topPerformers = User::where('role_type', 'user')
                            ->withSum(['attendances as total_hours' => function($query) use ($startOfMonth, $endOfMonth) {
                                $query->whereBetween('attendance_date', [$startOfMonth, $endOfMonth]);
                            }], 'work_hours')
                            ->withCount(['attendances as present_days' => function($query) use ($startOfMonth, $endOfMonth) {
                                $query->whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                      ->whereIn('status', ['on_time', 'late']);
                            }])
                            ->withCount(['attendances as late_days' => function($query) use ($startOfMonth, $endOfMonth) {
                                $query->whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                      ->where('status', 'late');
                            }])
                            ->having('total_hours', '>', 0)
                            ->orderByDesc('total_hours')
                            ->take(5)
                            ->get();
        
        // Recent Attendance (Last 10 with any check-in)
        $recentAttendance = Attendance::with(['user'])
                                     ->where(function($query) {
                                         $query->whereNotNull('morning_check_in')
                                               ->orWhereNotNull('afternoon_check_in');
                                     })
                                     ->orderBy('created_at', 'desc')
                                     ->take(10)
                                     ->get();
        
        // Daily Attendance for Last 7 Days (for chart)
        $last7Days = collect();
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $dayAttendances = Attendance::whereDate('attendance_date', $date)->get();
            
            $last7Days->push([
                'date' => $date->format('D'),
                'full_date' => $date->format('M d'),
                'present' => $dayAttendances->whereIn('status', ['on_time', 'late'])->count(),
                'late' => $dayAttendances->where('status', 'late')->count(),
                'absent' => $dayAttendances->where('status', 'absent')->count(),
                'leave' => $dayAttendances->where('status', 'leave')->count(),
            ]);
        }
        
        // Status Distribution (This Month)
        $statusDistribution = [
            'on_time' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                  ->where('status', 'on_time')
                                  ->count(),
            'late' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                               ->where('status', 'late')
                               ->count(),
            'absent' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                 ->where('status', 'absent')
                                 ->count(),
            'leave' => Attendance::whereBetween('attendance_date', [$startOfMonth, $endOfMonth])
                                ->where('status', 'leave')
                                ->count(),
        ];
        
        // Office Location Usage
        $locationStats = OfficeLocation::withCount(['attendances' => function($query) use ($startOfMonth, $endOfMonth) {
                                          $query->whereBetween('attendance_date', [$startOfMonth, $endOfMonth]);
                                      }])
                                      ->having('attendances_count', '>', 0)
                                      ->orderByDesc('attendances_count')
                                      ->get();
        
        // Today's Summary with Morning/Afternoon breakdown
        $todayAttendances = Attendance::whereDate('attendance_date', today())->get();
        
        $todaySummary = [
            'morning_checked_in' => $todayAttendances->whereNotNull('morning_check_in')->count(),
            'afternoon_checked_in' => $todayAttendances->whereNotNull('afternoon_check_in')->count(),
            'on_time' => $todayAttendances->where('status', 'on_time')->count(),
            'late' => $todayAttendances->where('status', 'late')->count(),
            'complete_days' => $todayAttendances->filter(function($attendance) {
                return $attendance->isFullDayComplete();
            })->count(),
            'pending' => User::where('role_type', 'user')->count() - 
                        $todayAttendances->whereNotNull('morning_check_in')->count(),
        ];
        
        return view('admin.dashboard', compact(
            'stats',
            'topPerformers',
            'recentAttendance',
            'last7Days',
            'statusDistribution',
            'locationStats',
            'todaySummary'
        ));
    }

  public function qrmake(){
    return view("admin.qrmake");
  }

    public function attendance(Request $request)
    {
        $activeTab = $request->get('tab', 'schedules');

        $users = User::where('role_type', 'user')
                    ->with('attendanceSchedule')
                    ->orderBy('name')
                    ->paginate(9, ['*'], 'schedules_page')
                    ->appends(['tab' => 'schedules']);

        $dayOffs = AttendanceOffDay::with('user')
                                  ->orderBy('off_date', 'desc')
                                  ->paginate(10, ['*'], 'dayoffs_page')
                                  ->appends(['tab' => 'dayoffs']);

        $attendances = Attendance::with('user')
                                ->whereMonth('attendance_date', now()->month)
                                ->orderBy('attendance_date', 'desc')
                                ->paginate(15, ['*'], 'records_page')
                                ->appends(['tab' => 'records']);

        return view('admin.adminattendance', compact('users', 'dayOffs', 'attendances', 'activeTab'));
    }


        public function mapcreated()
    {
        $locations = OfficeLocation::orderBy('created_at', 'desc')->paginate(9);
        return view('admin.map', compact('locations'));
    }

    public function create()
    {
        return view('admin.map-create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'nullable|string|max:500',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'radius' => 'required|integer|min:10|max:1000',
            'description' => 'nullable|string|max:1000',
            'is_active' => 'nullable|boolean',
        ]);

        $validated['is_active'] = $request->has('is_active');

        OfficeLocation::create($validated);

        return redirect()->route('map.created')
                       ->with('success', 'Location created successfully!');
    }

    public function edit($id)
    {
        $location = OfficeLocation::findOrFail($id);
        return view('admin.map-edit', compact('location'));
    }

    public function update(Request $request, $id)
    {
        $location = OfficeLocation::findOrFail($id);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'nullable|string|max:500',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'radius' => 'required|integer|min:10|max:1000',
            'description' => 'nullable|string|max:1000',
            'is_active' => 'nullable|boolean',
        ]);

        $validated['is_active'] = $request->has('is_active');

        $location->update($validated);

        return redirect()->route('map.created')
                       ->with('success', 'Location updated successfully!');
    }

    public function toggle($id)
    {
        $location = OfficeLocation::findOrFail($id);
        $location->is_active = !$location->is_active;
        $location->save();

        return redirect()->route('map.created')
                       ->with('success', 'Location status updated successfully!');
    }

    public function destroy($id)
    {
        $location = OfficeLocation::findOrFail($id);
        $location->delete();

        return redirect()->route('map.created')
                       ->with('success', 'Location deleted successfully!');
    }
  

       public function report(Request $request)
    {
        // Get filter parameters
        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));
        $userId = $request->input('user_id');
        
        // Get all users or specific user - OLD users first
        $users = User::where('role_type', 'user')
                     ->when($userId, function($q) use ($userId) {
                         $q->where('id', $userId);
                     })
                     ->orderBy('created_at') // OLD users first (ascending)
                     ->orderBy('name')
                     ->get();
        
        // Generate date range (only working days - Monday to Friday)
        $dateRange = [];
        $currentDate = Carbon::parse($startDate);
        $endDateCarbon = Carbon::parse($endDate);
        
        while ($currentDate->lte($endDateCarbon)) {
            // Only include Monday (1) to Friday (5)
            $dayOfWeek = $currentDate->dayOfWeek;
            if ($dayOfWeek >= Carbon::MONDAY && $dayOfWeek <= Carbon::FRIDAY) {
                $dateRange[] = $currentDate->copy();
            }
            $currentDate->addDay();
        }
        
        // Get existing attendances
        $existingAttendances = Attendance::with(['user'])
                              ->whereBetween('attendance_date', [$startDate, $endDate])
                              ->when($userId, function($q) use ($userId) {
                                  $q->where('user_id', $userId);
                              })
                              ->get()
                              ->groupBy(function($item) {
                                  return $item->user_id . '_' . $item->attendance_date->format('Y-m-d');
                              });
        
        // Get missions for the date range - using date part of created_at
        $missions = Mission::with(['user'])
                          ->whereDate('created_at', '>=', $startDate)
                          ->whereDate('created_at', '<=', $endDate)
                          ->when($userId, function($q) use ($userId) {
                              $q->where('user_id', $userId);
                          })
                          ->get()
                          ->groupBy(function($item) {
                              return $item->user_id . '_' . $item->created_at->format('Y-m-d');
                          });
        
        // Build complete attendance records (existing + missing)
        $allAttendances = collect();
        
        foreach ($users as $user) {
            foreach ($dateRange as $date) {
                $key = $user->id . '_' . $date->format('Y-m-d');
                
                if (isset($existingAttendances[$key])) {
                    // Use existing attendance
                    $attendance = $existingAttendances[$key]->first();
                    
                    // Mark as absent if no check-ins
                    if (is_null($attendance->morning_check_in) && 
                        is_null($attendance->afternoon_check_in) && 
                        $attendance->status !== 'leave') {
                        $attendance->status = 'absent';
                        if (empty($attendance->absent_note)) {
                            $attendance->absent_note = 'No check-in recorded';
                        }
                    }
                    
                    // Attach missions for this day
                    $attendance->day_missions = $missions[$key] ?? collect([]);
                    
                    $allAttendances->push($attendance);
                } else {
                    // Create virtual attendance record for missing data
                    $virtualAttendance = new Attendance([
                        'user_id' => $user->id,
                        'attendance_date' => $date,
                        'status' => 'absent',
                        'absent_note' => 'No attendance record',
                        'work_hours' => 0,
                    ]);
                    $virtualAttendance->user = $user;
                    $virtualAttendance->exists = false; // Mark as virtual
                    $virtualAttendance->day_missions = $missions[$key] ?? collect([]);
                    
                    $allAttendances->push($virtualAttendance);
                }
            }
        }
        
        // Sort by date desc first, then keep user order (old users first)
        $allAttendances = $allAttendances->sortByDesc(function($item) {
            return $item->attendance_date->format('Y-m-d');
        })->values();
        
        // Paginate manually
        $perPage = 20;
        $currentPage = $request->input('page', 1);
        $attendances = new \Illuminate\Pagination\LengthAwarePaginator(
            $allAttendances->forPage($currentPage, $perPage),
            $allAttendances->count(),
            $perPage,
            $currentPage,
            ['path' => $request->url(), 'query' => $request->query()]
        );
        
        // Calculate statistics from all records
        $stats = [
            'total_present' => $allAttendances->whereIn('status', ['on_time', 'late'])->count(),
            'total_late' => $allAttendances->where('status', 'late')->count(),
            'total_absent' => $allAttendances->where('status', 'absent')->count(),
            'total_leave' => $allAttendances->where('status', 'leave')->count(),
            'total_hours' => $allAttendances->sum('work_hours'),
            'avg_hours' => $allAttendances->avg('work_hours'),
            'total_morning_hours' => $allAttendances->sum(function($a) {
                return $a->morning_work_hours ?? 0;
            }),
            'total_afternoon_hours' => $allAttendances->sum(function($a) {
                return $a->afternoon_work_hours ?? 0;
            }),
        ];
        
        // Get top 5 users by work hours
        $topUsers = User::where('role_type', 'user')
                       ->withSum(['attendances as total_hours' => function($query) use ($startDate, $endDate) {
                           $query->whereBetween('attendance_date', [$startDate, $endDate])
                                 ->whereRaw('DAYOFWEEK(attendance_date) BETWEEN 2 AND 6'); // Monday to Friday
                       }], 'work_hours')
                       ->withCount(['attendances as total_days' => function($query) use ($startDate, $endDate) {
                           $query->whereBetween('attendance_date', [$startDate, $endDate])
                                 ->whereIn('status', ['on_time', 'late'])
                                 ->whereRaw('DAYOFWEEK(attendance_date) BETWEEN 2 AND 6'); // Monday to Friday
                       }])
                       ->having('total_hours', '>', 0)
                       ->orderByDesc('total_hours')
                       ->take(5)
                       ->get();
        
        // Daily attendance summary
        $dailySummary = $allAttendances->groupBy(function($item) {
            return $item->attendance_date->format('Y-m-d');
        })->map(function($dayAttendances) {
            $date = $dayAttendances->first()->attendance_date;
            return [
                'date' => $date->format('Y-m-d'),
                'day_name' => $date->format('l'),
                'day_name_short' => $date->format('D'),
                'present' => $dayAttendances->whereIn('status', ['on_time', 'late'])->count(),
                'late' => $dayAttendances->where('status', 'late')->count(),
                'absent' => $dayAttendances->where('status', 'absent')->count(),
                'leave' => $dayAttendances->where('status', 'leave')->count(),
                'total_hours' => $dayAttendances->sum('work_hours'),
            ];
        })->sortBy('date')->values();
        
        // Get all users for filter dropdown
        $allUsers = User::where('role_type', 'user')->orderBy('name')->get();
        
        // Get office locations
        $locations = OfficeLocation::all();
        
        return view('admin.report', compact(
            'attendances',
            'stats',
            'topUsers',
            'dailySummary',
            'allUsers',
            'locations',
            'startDate',
            'endDate',
            'userId'
        ));
    }

    public function exportCSV(Request $request)
    {
        // Get filter parameters
        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate   = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));
        $userId    = $request->input('user_id');

        // Get all users or specific user - OLD users first
        $users = User::where('role_type', 'user')
                     ->when($userId, function($q) use ($userId) {
                         $q->where('id', $userId);
                     })
                     ->orderBy('created_at') // OLD users first (ascending)
                     ->orderBy('name')
                     ->get();
        
        // Generate date range (only Monday to Friday)
        $dateRange = [];
        $currentDate = Carbon::parse($startDate);
        $endDateCarbon = Carbon::parse($endDate);
        
        while ($currentDate->lte($endDateCarbon)) {
            $dayOfWeek = $currentDate->dayOfWeek;
            if ($dayOfWeek >= Carbon::MONDAY && $dayOfWeek <= Carbon::FRIDAY) {
                $dateRange[] = $currentDate->copy();
            }
            $currentDate->addDay();
        }
        
        // Get existing attendances
        $existingAttendances = Attendance::with(['user'])
                              ->whereBetween('attendance_date', [$startDate, $endDate])
                              ->when($userId, function($q) use ($userId) {
                                  $q->where('user_id', $userId);
                              })
                              ->get()
                              ->groupBy(function($item) {
                                  return $item->user_id . '_' . $item->attendance_date->format('Y-m-d');
                              });
        
        // Get missions - using date part of created_at
        $missions = Mission::with(['user'])
                          ->whereDate('created_at', '>=', $startDate)
                          ->whereDate('created_at', '<=', $endDate)
                          ->when($userId, function($q) use ($userId) {
                              $q->where('user_id', $userId);
                          })
                          ->get()
                          ->groupBy(function($item) {
                              return $item->user_id . '_' . $item->created_at->format('Y-m-d');
                          });
        
        // Build complete attendance records
        $attendances = collect();
        
        foreach ($users as $user) {
            foreach ($dateRange as $date) {
                $key = $user->id . '_' . $date->format('Y-m-d');
                
                if (isset($existingAttendances[$key])) {
                    $attendance = $existingAttendances[$key]->first();
                    
                    if (is_null($attendance->morning_check_in) && 
                        is_null($attendance->afternoon_check_in) && 
                        $attendance->status !== 'leave') {
                        $attendance->status = 'absent';
                        if (empty($attendance->absent_note)) {
                            $attendance->absent_note = 'No check-in recorded';
                        }
                    }
                    
                    $attendance->day_missions = $missions[$key] ?? collect([]);
                    $attendances->push($attendance);
                } else {
                    $virtualAttendance = new Attendance([
                        'user_id' => $user->id,
                        'attendance_date' => $date,
                        'status' => 'absent',
                        'absent_note' => 'No attendance record',
                        'work_hours' => 0,
                        'morning_work_hours' => 0,
                        'afternoon_work_hours' => 0,
                    ]);
                    $virtualAttendance->user = $user;
                    $virtualAttendance->day_missions = $missions[$key] ?? collect([]);
                    
                    $attendances->push($virtualAttendance);
                }
            }
        }
        
        // Sort by date ascending
        $attendances = $attendances->sortBy(function($item) {
            return $item->attendance_date->format('Y-m-d');
        })->values();

        // Filename
        $filename = 'attendance-report-' . now()->format('Y-m-d-His') . '.csv';

        // Headers
        $headers = [
            'Content-Type'        => 'text/csv; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Pragma'              => 'no-cache',
            'Cache-Control'       => 'must-revalidate, post-check=0, pre-check=0',
            'Expires'             => '0',
        ];

        // Stream CSV
        $callback = function () use ($attendances) {
            $file = fopen('php://output', 'w');

            // UTF-8 BOM (Excel safe)
            fprintf($file, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // CSV Header Row
            fputcsv($file, [
                'Employee',
                'Day',
                'Date',
                'Morning Check-In',
                'Morning Check-Out',
                'Afternoon Check-In',
                'Afternoon Check-Out',
                'Morning Status',
                'Afternoon Status',
                'Mission Status',
                'Mission Check-In',
            ]);

            // CSV Rows
            foreach ($attendances as $attendance) {
                // Format morning/afternoon status
                $morningStatus = ($attendance->morning_work_hours === null || $attendance->morning_work_hours == 0)
                    ? '--' 
                    : 'វត្តមាន';
                    
                $afternoonStatus = ($attendance->afternoon_work_hours === null || $attendance->afternoon_work_hours == 0)
                    ? '--' 
                    : 'វត្តមាន';
                
                // Format mission status and check-in
                $missionStatus = '--';
                $missionCheckIn = '--';
                
                if (isset($attendance->day_missions) && $attendance->day_missions->count() > 0) {
                    $mission = $attendance->day_missions->first();
                    
                    // Mission status in Khmer
                    if ($mission->status === 'approved') {
                        $missionStatus = 'បេសកកម្ម';
                    } elseif ($mission->status === 'pending') {
                        $missionStatus = 'ពិនិត្យ';
                    } else {
                        $missionStatus = '--';
                    }
                    
                    // Mission check-in time (using created_at)
                    if ($mission->check_in_time) {
                        $missionCheckIn = Carbon::parse($mission->check_in_time)->format('H:i:s');
                    } else {
                        $missionCheckIn = $mission->created_at->format('H:i:s');
                    }
                }
                
                fputcsv($file, [
                    $attendance->user->name,
                    $attendance->attendance_date->format('l'),
                    $attendance->attendance_date->format('Y-m-d'),
                    $attendance->morning_check_in ? $attendance->morning_check_in->format('H:i:s') : '-',
                    $attendance->morning_check_out ? $attendance->morning_check_out->format('H:i:s') : '-',
                    $attendance->afternoon_check_in ? $attendance->afternoon_check_in->format('H:i:s') : '-',
                    $attendance->afternoon_check_out ? $attendance->afternoon_check_out->format('H:i:s') : '-',
                    $morningStatus,
                    $afternoonStatus,
                    $missionStatus,
                    $missionCheckIn,
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
// notification

/**
 * Display notifications with filters
 */
public function notifications(Request $request)
{
    $query = Notification::where('user_id', Auth::id());

    // Search filter
    if ($request->filled('search')) {
        $search = $request->search;
        $query->where(function($q) use ($search) {
            $q->where('title', 'like', "%{$search}%")
              ->orWhere('message', 'like', "%{$search}%");
        });
    }

    // Type filter
    if ($request->filled('type')) {
        $query->where('type', $request->type);
    }

    // Status filter
    if ($request->filled('status')) {
        if ($request->status === 'unread') {
            $query->unread();
        } elseif ($request->status === 'read') {
            $query->read();
        }
    }

    // Date filter
    if ($request->filled('date_from')) {
        $query->whereDate('created_at', '>=', $request->date_from);
    }

    if ($request->filled('date_to')) {
        $query->whereDate('created_at', '<=', $request->date_to);
    }

    // Get paginated notifications
    $notifications = $query->orderBy('created_at', 'desc')
                          ->paginate(20)
                          ->withQueryString();

    // Statistics
    $stats = [
        'total' => Notification::where('user_id', Auth::id())->count(),
        'unread' => Notification::where('user_id', Auth::id())->unread()->count(),
        'today' => Notification::where('user_id', Auth::id())
                              ->whereDate('created_at', today())
                              ->count(),
    ];

    // Notification types count (optional, if needed in view)
    $typeStats = Notification::where('user_id', Auth::id())
                            ->selectRaw('type, count(*) as count')
                            ->groupBy('type')
                            ->get()
                            ->pluck('count', 'type');

    return view('admin.notifications', compact('notifications', 'stats', 'typeStats'));
}

/**
 * Mark single notification as read
 */
public function markNotificationRead($id)
{
    $notification = Notification::where('user_id', Auth::id())->findOrFail($id);
    $notification->markAsRead();
    
    return back()->with('success', 'Notification marked as read');
}

/**
 * Mark all notifications as read
 */
public function markAllNotificationsRead()
{
    $updatedCount = Notification::where('user_id', Auth::id())
                                ->unread()
                                ->update([
                                    'is_read' => true,
                                    'read_at' => now(),
                                ]);
    
    if ($updatedCount > 0) {
        return back()->with('success', "Successfully marked {$updatedCount} notification(s) as read");
    }
    
    return back()->with('success', 'No unread notifications to mark');
}

/**
 * Delete single notification
 */
public function deleteNotification($id)
{
    $notification = Notification::where('user_id', Auth::id())->findOrFail($id);
    $notification->delete();
    
    return back()->with('success', 'Notification deleted successfully');
}

/**
 * Delete all read notifications
 */
/**
 * Delete all read notifications
 */
public function deleteAllReadNotifications()
{
    try {
        // Get the count first
        $readNotifications = Notification::where('user_id', Auth::id())
                                        ->where('is_read', true)
                                        ->get();
        
        $count = $readNotifications->count();
        
        if ($count === 0) {
            return back()->with('error', 'No read notifications to delete');
        }
        
        // Delete them
        Notification::where('user_id', Auth::id())
                   ->where('is_read', true)
                   ->delete();
        
        return back()->with('success', "Successfully deleted {$count} read notification(s)");
        
    } catch (\Exception $e) {
        Log::error('Delete All Read Notifications Error', [
            'user_id' => Auth::id(),
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        
        return back()->with('error', 'Failed to delete notifications. Please try again.');
    }
}
}
